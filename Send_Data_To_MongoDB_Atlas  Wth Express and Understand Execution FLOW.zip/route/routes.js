import express,{Router} from 'express';
import { getuser } from '../controller/user-controller.js';



console.log("Before run const app=express(); Inside Routes.js");
const app=express();
const route =express.Router();
console.log("After run const route =express.Router(); Inside Routes.js");


route.get('/user',getuser);
console.log("After run route.get(/user,getuser) Inside Routes.js");


export default route;

console.log("END............ROUtes.JS")