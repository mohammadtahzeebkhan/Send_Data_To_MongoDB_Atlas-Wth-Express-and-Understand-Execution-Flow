import  mongoose  from "mongoose";

console.log("Before create const userschema=mongoose.Schema( Inside user-schema.js");


 

const userschema=mongoose.Schema({
    name:String,
    username:String,
    email:String,
    phone:Number,
});
const user=mongoose.model('myfirstdatabase',userschema);

console.log("After const user=mongoose.model('user',userschema); Inside user-schema.js");
export default user;

console.log("END............USER SCHEMA.JS")