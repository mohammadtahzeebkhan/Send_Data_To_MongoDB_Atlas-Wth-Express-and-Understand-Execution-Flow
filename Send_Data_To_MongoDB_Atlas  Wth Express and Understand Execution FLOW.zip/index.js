import mongoose from 'mongoose';
import express from 'express';
const app=express();

import route from './route/routes.js'

console.log('Before import Inside INDEX.js');
const PORT=8000;
URL="mongodb+srv://user:pass123@cluster0.dyvx5.mongodb.net/myfirstdatabase?retryWrites=true&w=majority"


console.log('run Before app.use('/',route); INside INDEX.js');

app.use('/',route);

mongoose.connect(URL,{useNewUrlParser:true,useUnifieldTopology:true,useFindAndModify:false}).then(()=>{
    console.log('AFTER run mongoose.connect INside INDEX.js');

app.listen(8000,()=>{
    console.log('server is running...${PORT} Inside INDEX.js');
    console.log('AFTER Refreshing..................... Inside INDEX.js');


});

}).catch(error =>{
    console.log('Error',error.message);
})

console.log("END............INDEX.JS")