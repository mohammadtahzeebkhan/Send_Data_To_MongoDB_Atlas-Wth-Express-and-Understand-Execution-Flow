import user from "../model/user-schema.js";


const v={
name:'mohammad tahzeeb khan',
username:'paradisehope',
email:'mohammadtahzeebkhan@gmail.com',
phone:6353026573,
};

console.log('run After create json variable INside Uer-Controller.js');


export const getuser=async(request,response)=>{
    console.log('run After export const getuser=async(request,response)=> INside Uer-Controller.js');

    const newuser=new user(v);
    console.log('run After const newuser=new user(v); INside Uer-Controller.js');

    response.status(200).json("hi from paradisehope");
    try{
        console.log('run Before Inside TRY await newuser.save(); INside Uer-Controller.js');

     await newuser.save();
     

     console.log('run After Inside TRY await newuser.save(); INside Uer-Controller.js');

    }
    catch(error){
        response.status(200).json("hi from Error ");
        console.log('run Before inside CATCH  INside Uer-Controller.js');


        
    }

}


    console.log("END............USER CONTROLLER.JS")
